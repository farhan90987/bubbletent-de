=== Seraphinite Accelerator ===
Contributors: seraphinitesoft
Donate link: https://www.s-sols.com/products/wordpress/accelerator#offer
Tags: optimize,pagespeed,performance,speed up,cache
Requires PHP: 7.1
Requires at least: 4.5
Tested up to: 6.8
Stable tag: 2.27.44
License: GPLv2 or later (if another license is not provided)
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Privacy policy: https://www.s-sols.com/privacy-policy

Turns on site high speed to be attractive for people and search engines.

== Description ==

Turns on site high speed to be attractive for people and search engines. See more [how to use it](https://www.s-sols.com/docs/wordpress/accelerator/getting-started-accel).

**TO USE FREE ADDITIONAL FEATURES PLEASE INSTALL THE FREE EXTENDED PLUGIN VERSION BY FOLLOWING ONSCREEN PLUGIN'S INSTRUCTIONS.**

We kindly ask you to [post reviews](https://wordpress.org/support/plugin/seraphinite-accelerator/reviews?rate=5#new-post) to share experience about your site speed - it helps improving the plugin.



[More details](https://www.s-sols.com/products/wordpress/accelerator).





== Installation ==

1. Choose the plugin from the WordPress repository, or choose the plugin's archive file in 'Upload Plugin' section in WordPress 'Plugins\Add New', or upload and extract the plugin archive to the '/wp-content/plugins' directory manually.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. It will appear in the admin UI as shown in the [screenshots](http://wordpress.org/plugins/seraphinite-accelerator/screenshots).




