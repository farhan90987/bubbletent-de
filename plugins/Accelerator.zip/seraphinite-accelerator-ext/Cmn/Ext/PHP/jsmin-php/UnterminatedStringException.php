<?php

namespace seraph_accel\JSMin;

class UnterminatedStringException extends \Exception {
}
